
package projj1;
import java.io.*;
import java.util.*; 
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;


public class Projj1  extends Application
{
    @Override
    public void start(Stage primaryStage)
    {
        primaryStage.setTitle("WordCount Application");
       
        //UI
        Label titleLabel=new Label("WordCount Application");
        Label inputLabel=new Label("Enter Your Information Or Enter A File Path :"+" File In ( .txt )Form :"+"\n");
        TextField inputfield =new TextField();
        Button countButton=new Button("Count Word");
        TextArea resultArea=new TextArea();
        
        //Button EventHandling
        countButton.setOnAction(event->{
         String input=inputfield.getText().trim();
            if(input.isEmpty())
            {
                resultArea.setText("Invalid Information or File Path ");
            return;
            }
            
        String text="";
        if(input.endsWith(".txt"))
        {
           text=readTextFromFile(input);
           if(text.isEmpty())
           {
               resultArea.setText("File Not Found or Error Reading File!");
           return;
           }
        }
        else 
        {
            text=input;
        }
        
         int wordcount=countWords(text);
         System.out.println("Number of Word : "+wordcount );
         
         Set<String> uniqueWords=getUniqueWords(text);
         Map<String,Integer> wordFrequency=getWordFrequency(text);
         
         
         resultArea.setText("Number of Word : "+wordcount+"\n"+"Number of Unique Words :"+uniqueWords.size()+"\n"+"Word Frequency : "+wordFrequencyToString(wordFrequency));
     
        });
        
        //Layout
        VBox Layout=new VBox(10);
        Layout.getChildren().addAll(titleLabel,inputLabel,inputfield,countButton,resultArea);
        
        //Scene
        Scene s=new Scene(Layout,400,300);
        primaryStage.setScene(s);
        primaryStage.show();
    
    }
        
        private int countWords(String text) 
        {
        String[] words = text.split("[\\s\\p{Punct}]+");
        return words.length;
        }
          
        private Set<String> getUniqueWords(String text)
        {
        Set<String>  UniqueWords=new HashSet();
        String[] words=text.split("[\\s\\p{Punct}]+");
        return new HashSet<>(Arrays.asList(words));
        }
       
        private Map<String, Integer> getWordFrequency(String text) {
        Map<String, Integer> wordFrequency = new HashMap<>();
        String[] words = text.split("[\\s\\p{Punct}]+");
        for (String word : words) {
            wordFrequency.put(word.toLowerCase(), wordFrequency.getOrDefault(word.toLowerCase(), 0) + 1);
        }
        return wordFrequency;
    }

    private String wordFrequencyToString(Map<String, Integer> wordFrequency) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> entry : wordFrequency.entrySet()) {
            sb.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }
        return sb.toString();
    }

    private String readTextFromFile(String filepath) {
        StringBuilder sb = new StringBuilder();

        try {
            Scanner sc1 = new Scanner(new File(filepath));

            while (sc1.hasNextLine()) {
                sb.append(sc1.nextLine()).append("\n");
            }
            sc1.close();
        } catch (Exception e)
        {
            e.printStackTrace();
            return "";
        }
        return sb.toString();
    }
    
    public static void main(String[] args)
    {
   launch(args);
    }
}
