
package studentmanagementsystemgui;

import java.io.*;
import java.util.ArrayList;
class Student
{
private String name;
private int roll;
private String Grade;


    public Student(String name ,int roll,String Grade)
    {
    this.name=name;
    this.roll=roll;
    this.Grade=Grade;
    }

    public String getName()
    {
        return name;    
    }
    
    public void setName(String name)
    {
        this.name=name;
    }

    public int getRoll()
    {
        return roll;
    }
   
    public void setRoll(int roll)
    {
        this.roll=roll;
    }
    
    public String getGrade()
    {
        return Grade;
    }
    
    public void setGrade(String Grade)
    {
        this.Grade=Grade;
    }
    
}

public class StudentManagementSystem
{
    
    private ArrayList<Student> students;
            
    public StudentManagementSystem()
    {
        students=new ArrayList<>();
    }
    
    public void addStudent(String name,int roll,String grade)
    { 
        Student s=new Student(name ,roll,grade);
        students.add(s);
    }
    
    public void removeStudent(int roll)
    {
        for(int i=0;i<students.size();i++)
        {
            if(students.get(i).getRoll()==roll)
            {
                students.remove(i);
                System.out.println("Student with roll number "+roll+"Removed SuccessFully.");
                return ;
            }
        }
        System.out.println("Student with roll number " + roll + " not found.");
    }
    
    public Student searchStudentByName(String name)
    {
        for(Student s:students)
        {
            if(s.getName().equalsIgnoreCase(name))
            {
                return s;
            }
        }
        return null;
    }
    
    
    public void displayAllStudents()
    {
        System.out.println("List of Students");
        for(Student s:students)
        {
            System.out.println("Student-Name: "+s.getName()+" ,Roll-No:"+s.getRoll()+" ,Grade:"+s.getGrade());
        }
    }
    
    public void updateStudent(int roll, String newName, String newGrade) {
    for (Student student : students) {
        if (student.getRoll() == roll) {
            student.setName(newName);
            student.setGrade(newGrade);
            System.out.println("Student with roll number " + roll + " updated successfully.");
            return;
        }
    }
    System.out.println("Student with roll number " + roll + " not found.");
    }
    public void saveToFile(String fileName) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (Student student : students) {
                writer.println(student.getName() + "," + student.getRoll() + "," + student.getGrade());
            }
            System.out.println("Student data saved to file: " + fileName);
        } catch (IOException e) {
            System.err.println("Error saving student data to file: " + fileName);
            e.printStackTrace();
        }
    }

    public void loadFromFile(String fileName) {
        students.clear(); 
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String name = parts[0].trim();
                    int roll = Integer.parseInt(parts[1].trim());
                    String grade = parts[2].trim();
                    students.add(new Student(name, roll, grade));
                }
            }
            System.out.println("Student data loaded from file: " + fileName);
        } catch (IOException e) {
            System.err.println("Error loading student data from file: " + fileName);
            e.printStackTrace();
        }
        
    }
}
