package studentmanagementsystemgui;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class StudentManagementSystemGUI extends Application
{
    private StudentManagementSystem system;

    @Override
public void start(Stage primaryStage) {
    system = new StudentManagementSystem();

    GridPane grid = new GridPane();
    grid.setPadding(new Insets(20));
    grid.setHgap(10);
    grid.setVgap(10);

    Label nameLabel = new Label("Name:");
    TextField nameField = new TextField();
    Label rollLabel = new Label("Roll Number:");
    TextField rollField = new TextField();
    Label gradeLabel = new Label("Grade:");
    TextField gradeField = new TextField();

    Button addButton = new Button("Add Student");
        addButton.setOnAction(event -> {
            String name = nameField.getText();
            String roll = rollField.getText();
            String grade = gradeField.getText();
            if (validateInput(name, roll, grade)) {
                int rollNumber = Integer.parseInt(roll);
                system.addStudent(name, rollNumber, grade);
                refreshDisplay();
            }
        });

    Button removeButton = new Button("Remove Student");
        removeButton.setOnAction(event -> {
            String roll = rollField.getText();
            if (validateRollNumber(roll)) {
                int rollNumber = Integer.parseInt(roll);
                system.removeStudent(rollNumber);
                refreshDisplay();
            }
        });

    Button searchButton = new Button("Search Student");
        searchButton.setOnAction(event -> {
            String name = nameField.getText();
            Student foundStudent = system.searchStudentByName(name);
            if (foundStudent != null) {
                showAlert(Alert.AlertType.INFORMATION, "Student Found",
                        "Student found: Name: " + foundStudent.getName() +
                                ", Roll: " + foundStudent.getRoll() +
                                ", Grade: " + foundStudent.getGrade());
            } else {
                showAlert(Alert.AlertType.WARNING, "Student Not Found", "Student with name " + name + " not found.");
            }
        });

    

    Button displayButton = new Button("Display All Students");
    displayButton.setOnAction(event -> system.displayAllStudents());

    
    
   Button updateButton = new Button("Update Student");
        updateButton.setOnAction(event -> {
            String name = nameField.getText();
            String roll = rollField.getText();
            String grade = gradeField.getText();
            if (validateInput(name, roll, grade)) {
                int rollNumber = Integer.parseInt(roll);
                system.updateStudent(rollNumber, name, grade);
                refreshDisplay();
            }
        });
    
    Button exitButton = new Button("Exit");
    exitButton.setOnAction(event -> {
    primaryStage.close();
    });
    
    grid.add(nameLabel, 0, 0);
    grid.add(nameField, 1, 0);
    grid.add(rollLabel, 0, 1);
    grid.add(rollField, 1, 1);
    grid.add(gradeLabel, 0, 2);
    grid.add(gradeField, 1, 2);
    grid.add(addButton, 0, 3);
    grid.add(removeButton, 1, 3);
    grid.add(searchButton, 0, 4);
    grid.add(displayButton, 1, 4);
    grid.add(updateButton, 0, 5); // Add the updateButton
    grid.add(exitButton, 1, 5);
    
    Scene scene = new Scene(grid, 400, 300);
    primaryStage.setTitle("Student Management System");
    primaryStage.setScene(scene);
    primaryStage.show();
}

    private void refreshDisplay() {
       
    }

   private boolean validateInput(String name, String roll, String grade) {
        if (name.isEmpty() || roll.isEmpty() || grade.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            return false;
        }
        try {
            int rollNumber = Integer.parseInt(roll);
            return true;
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid roll number format.");
            return false;
        }
    }

    private boolean validateName(String name) {
        if (name.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter a name.");
            return false;
        }
        return true;
    }

    private boolean validateRollNumber(String roll) {
        if (roll.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter a roll number.");
            return false;
        }
        try {
            int rollNumber = Integer.parseInt(roll);
            return true;
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid roll number format.");
            return false;
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    public static void main(String[] args)
    {
     launch(args);
     StudentManagementSystem system = new StudentManagementSystem();
      system.saveToFile("students.txt");
      system.loadFromFile("students.txt");
    }
    
}