package project1;

import java.util.Random;
import java.util.Scanner;

public class Project1 
{
    public static void main(String[] args) 
    {  
        Scanner sc=new Scanner(System.in);
        int roundWon=0;
        
        while(true)
        {
            int roundScore=playGame(sc);
            
            roundWon=roundWon+roundScore;
            
            System.out.println("Want to Play This Game Again?: (yes/ no )");
            String playAgain=sc.next().toLowerCase();
            
            if(!playAgain.equals("yes"))
            {
                System.out.println("Thank you for Playing,Your Total Rounds Wons :"+roundWon);
                break;
            }
        }
    }
        
        private static int playGame(Scanner sc)
        {
        int Answer,Guess = 0;
       
       Random random=new Random();
       Answer=random.nextInt(100+1);
       int maxattempts=5;
       int attempts=0;
       int count=1;
       
       
       
       while(attempts < maxattempts)
       {
       System.out.println(count+":-Guess A Number Between 1- 100 :");
       Guess=sc.nextInt();
       attempts++;
       count++;
    
       if(Guess == Answer)
       {
           System.out.println("Excellent The Number is : "+Answer);
           return 1;
       }
       else if(Guess<Answer)
       {
           System.out.println("Sorry Number is Too low! Try again: "  );
       }
       else
       {
           System.out.println("Sorry Number is Too High! Try again: ");
       }
       }
       
      if (attempts == maxattempts && Guess != Answer)
      {
            System.out.println("Sorry, you've run out of attempts , The correct number was: " + Answer);
      }
      return 0;
    }   
}
